# Privacy Policy
This document is for those who consume Judge0 and not for those who deploy Judge0 to their own infrastructure.

If you deploy Judge0 to your own infrastructure then you should read about [telemetry](TELEMETRY.md).

## Collected Data
Judge0 does **not** store any personal information.

For every submission Judge0 stores the data that has been well documented [here](https://api.judge0.com/#submissions-submission).