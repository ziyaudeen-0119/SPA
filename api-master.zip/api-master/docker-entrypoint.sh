#!/bin/bash
cron
exec "$@"