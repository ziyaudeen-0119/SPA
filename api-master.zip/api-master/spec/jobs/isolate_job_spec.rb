require 'rails_helper'

RSpec.describe IsolateJob, type: :job do
end
