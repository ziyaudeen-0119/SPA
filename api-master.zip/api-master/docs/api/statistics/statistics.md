# Group Statistics
## Statistics [/statistics]
### Statistics [GET]
Get some statistics from current instance. Result is cached for 10 minutes.