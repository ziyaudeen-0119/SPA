+ Response 403
    Authorization failed. Please read about [authorization](#authorization) process.
    + Body