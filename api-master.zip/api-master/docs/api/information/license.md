## License [/license]
## License [GET]
Returns a license.