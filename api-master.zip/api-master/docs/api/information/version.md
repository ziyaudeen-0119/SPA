## Version [/version]
## Version [GET]
Returns current version.