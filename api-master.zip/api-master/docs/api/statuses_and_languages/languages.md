## Language [/languages/{id}]
<!-- include(get_languages.md) -->
<!-- include(get_a_language.md) -->
<!-- include(get_active_and_archived_languages.md) -->